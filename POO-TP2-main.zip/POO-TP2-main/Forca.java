public class Forca {
}
